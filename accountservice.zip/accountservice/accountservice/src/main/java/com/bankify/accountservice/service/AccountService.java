package com.bankify.accountservice.service;

import com.bankify.accountservice.entity.Account;
import com.bankify.accountservice.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {

    private final AccountRepository accountRepository;

    @Autowired
    public AccountService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    public Account getAccountById(Long id) {
        return accountRepository.findById(id).orElse(null);
    }

    public void updateBalance(Long id, Double amount) {
        Account account = getAccountById(id);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRepository.save(account);
        }
    }
    
    public List<Account> getAccountsByUserId(Long userId) {
        return accountRepository.findByUserId(userId);
    }
    
    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }
    
    public boolean hasSufficientFunds(Long accountId, Double amount) {
        Account account = getAccountById(accountId);
        return account != null && account.getBalance() >= amount;
    }
    
    public Account getAccountByAccountNumber(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber);
    }
    
    public boolean hasSufficientFundsByAccountNumber(String accountNumber, Double amount) {
        Account account = getAccountByAccountNumber(accountNumber);
        return account != null && account.getBalance() >= amount;
    }
    
    public void updateBalanceByAccountNumber(String accountNumber, Double amount) {
        Account account = getAccountByAccountNumber(accountNumber);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRepository.save(account);
        } else {
            throw new RuntimeException("Account not found with account number: " + accountNumber);
        }
    }
}
