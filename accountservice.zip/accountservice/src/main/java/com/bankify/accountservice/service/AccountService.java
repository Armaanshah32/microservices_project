package com.bankify.accountservice.service;

import com.bankify.accountservice.entity.Account;
import com.bankify.accountservice.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {

    private final AccountRepository accountRepository;

    @Autowired
    public AccountService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    public Account getAccountById(Long id) {
        return accountRepository.findById(id).orElse(null);
    }

    public void updateBalance(Long id, Double amount) {
        Account account = getAccountById(id);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRepository.save(account);
        }
    }
}
