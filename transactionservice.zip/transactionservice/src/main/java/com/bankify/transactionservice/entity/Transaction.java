package com.bankify.transactionservice.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column(nullable = true)
    private Long accountId;
    
    @Column
    private String sourceAccountNumber;
    
    @Column
    private String destinationAccountNumber;

    @Column(nullable = false)
    private Double amount;

    @ManyToOne
    @JoinColumn(name = "transaction_type_id", nullable = false)
    private TransactionType transactionType;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false, updatable = false)
    private Date createdAt;
    
    @Column(nullable = false)
    private Boolean active = true;
    
    @Column(nullable = false)
    private String status = "COMPLETED";
    
    @Column(name = "timestamp", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date timestamp;
    
    // Default constructor
    public Transaction() {
        Date now = new Date();
        this.createdAt = now;
        this.timestamp = now;
        this.active = true;
        this.status = "COMPLETED";
    }
    
    // Parameterized constructor
    public Transaction(Long accountId, Double amount, TransactionType transactionType) {
        Date now = new Date();
        this.accountId = accountId;
        this.amount = amount;
        this.transactionType = transactionType;
        this.createdAt = now;
        this.timestamp = now;
        this.active = true;
        this.status = "COMPLETED";
    }
    
    // Constructor for transfers
    public Transaction(String sourceAccountNumber, String destinationAccountNumber, Double amount, TransactionType transactionType) {
        Date now = new Date();
        this.sourceAccountNumber = sourceAccountNumber;
        this.destinationAccountNumber = destinationAccountNumber;
        this.amount = amount;
        this.transactionType = transactionType;
        this.createdAt = now;
        this.timestamp = now;
        this.active = true;
        this.status = "COMPLETED";
    }

    public Long getTransactionId() {
        return transactionId;
    }
    
    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public Date getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    
    public Boolean getActive() {
        return active;
    }
    
    public void setActive(Boolean active) {
        this.active = active;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Date getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
    
    public String getSourceAccountNumber() {
        return sourceAccountNumber;
    }
    
    public void setSourceAccountNumber(String sourceAccountNumber) {
        this.sourceAccountNumber = sourceAccountNumber;
    }
    
    public String getDestinationAccountNumber() {
        return destinationAccountNumber;
    }
    
    public void setDestinationAccountNumber(String destinationAccountNumber) {
        this.destinationAccountNumber = destinationAccountNumber;
    }
}
