package com.bankify.transactionservice.controller;

import com.bankify.transactionservice.entity.Transaction;
import com.bankify.transactionservice.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping
    public ResponseEntity<?> createTransaction(@RequestBody Transaction transaction) {
        try {
            if (transaction.getTransactionType() == null) {
                return ResponseEntity.badRequest().body("TransactionType is required");
            }
            
            // Ensure timestamp is set
            if (transaction.getTimestamp() == null) {
                transaction.setTimestamp(new Date());
            }
            
            // Ensure status is set
            if (transaction.getStatus() == null) {
                transaction.setStatus("COMPLETED");
            }
            
            Transaction createdTransaction = transactionService.createTransaction(transaction);
            return ResponseEntity.ok(createdTransaction);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("An error occurred while creating the transaction: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Transaction> getTransactionById(@PathVariable Long id) {
        Optional<Transaction> transaction = transactionService.getTransactionById(id);
        return transaction.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<Transaction> getAllTransactions() {
        return transactionService.getAllTransactions();
    }
    
    @PostMapping("/transfer")
    public ResponseEntity<?> transferBetweenAccounts(@RequestBody Transaction transaction) {
        try {
            System.out.println("Transfer request received: sourceAccount=" + transaction.getSourceAccountNumber() 
                + ", destinationAccount=" + transaction.getDestinationAccountNumber()
                + ", amount=" + transaction.getAmount());
            
            // Validate required fields
            if (transaction.getSourceAccountNumber() == null || transaction.getDestinationAccountNumber() == null) {
                return ResponseEntity.badRequest().body("Source and destination account numbers are required");
            }
            
            if (transaction.getAmount() == null || transaction.getAmount() <= 0) {
                return ResponseEntity.badRequest().body("Transfer amount must be positive");
            }
            
            // Ensure timestamp is set
            if (transaction.getTimestamp() == null) {
                transaction.setTimestamp(new Date());
            }
            
            // Process the transfer
            Transaction completedTransfer = transactionService.createTransfer(transaction);
            System.out.println("Transfer completed successfully with ID: " + completedTransfer.getTransactionId());
            return ResponseEntity.ok(completedTransfer);
        } catch (IllegalArgumentException e) {
            System.out.println("Transfer validation error: " + e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            System.out.println("Transfer failed with error: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(500).body("Transfer failed: " + e.getMessage());
        }
    }
    

}
