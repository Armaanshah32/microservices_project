package com.bankify.transactionservice.controller;

import com.bankify.transactionservice.entity.TransactionType;
import com.bankify.transactionservice.repository.TransactionTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * Controller for managing transaction types
 */
@RestController
@RequestMapping("/api/transaction-types")
public class TransactionTypeController {

    private final TransactionTypeRepository transactionTypeRepository;

    @Autowired
    public TransactionTypeController(TransactionTypeRepository transactionTypeRepository) {
        this.transactionTypeRepository = transactionTypeRepository;
    }

    /**
     * Create a new transaction type
     * @param transactionType The transaction type to create
     * @return The created transaction type
     */
    @PostMapping
    public ResponseEntity<TransactionType> createTransactionType(@RequestBody TransactionType transactionType) {
        // Validate input
        if (transactionType.getTypeName() == null || transactionType.getTypeName().trim().isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        
        // Check if a transaction type with the same name already exists
        Optional<TransactionType> existingType = transactionTypeRepository.findByTypeName(transactionType.getTypeName());
        if (existingType.isPresent()) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        
        // Set default values if not provided
        if (transactionType.getActive() == null) {
            transactionType.setActive(true);
        }
        
        TransactionType savedType = transactionTypeRepository.save(transactionType);
        return new ResponseEntity<>(savedType, HttpStatus.CREATED);
    }

    /**
     * Get all transaction types
     * @return List of all transaction types
     */
    @GetMapping
    public List<TransactionType> getAllTransactionTypes() {
        return transactionTypeRepository.findAll();
    }

    /**
     * Get a transaction type by ID
     * @param id The ID of the transaction type
     * @return The transaction type if found
     */
    @GetMapping("/{id}")
    public ResponseEntity<TransactionType> getTransactionTypeById(@PathVariable Long id) {
        Optional<TransactionType> transactionType = transactionTypeRepository.findById(id);
        return transactionType.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get a transaction type by name
     * @param name The name of the transaction type
     * @return The transaction type if found
     */
    @GetMapping("/by-name/{name}")
    public ResponseEntity<TransactionType> getTransactionTypeByName(@PathVariable String name) {
        Optional<TransactionType> transactionType = transactionTypeRepository.findByTypeName(name);
        return transactionType.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Update an existing transaction type
     * @param id The ID of the transaction type to update
     * @param transactionType The updated transaction type data
     * @return The updated transaction type
     */
    @PutMapping("/{id}")
    public ResponseEntity<TransactionType> updateTransactionType(
            @PathVariable Long id, 
            @RequestBody TransactionType transactionType) {
        
        if (!transactionTypeRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        
        // Set the ID to ensure we're updating the correct entity
        transactionType.setTypeId(id);
        
        // Validate name is not empty
        if (transactionType.getTypeName() == null || transactionType.getTypeName().trim().isEmpty()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        
        // Check if the new name conflicts with an existing type (other than this one)
        Optional<TransactionType> existingWithSameName = transactionTypeRepository.findByTypeName(transactionType.getTypeName());
        if (existingWithSameName.isPresent() && !existingWithSameName.get().getTypeId().equals(id)) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        
        TransactionType updatedType = transactionTypeRepository.save(transactionType);
        return ResponseEntity.ok(updatedType);
    }

    /**
     * Delete a transaction type
     * @param id The ID of the transaction type to delete
     * @return No content on success
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransactionType(@PathVariable Long id) {
        if (!transactionTypeRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        
        transactionTypeRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
    
    /**
     * Deactivate a transaction type instead of deleting it
     * @param id The ID of the transaction type to deactivate
     * @return The updated transaction type
     */
    @PutMapping("/{id}/deactivate")
    public ResponseEntity<TransactionType> deactivateTransactionType(@PathVariable Long id) {
        Optional<TransactionType> optionalType = transactionTypeRepository.findById(id);
        
        if (!optionalType.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        
        TransactionType transactionType = optionalType.get();
        transactionType.setActive(false);
        
        TransactionType updatedType = transactionTypeRepository.save(transactionType);
        return ResponseEntity.ok(updatedType);
    }
    
    /**
     * Activate a transaction type
     * @param id The ID of the transaction type to activate
     * @return The updated transaction type
     */
    @PutMapping("/{id}/activate")
    public ResponseEntity<TransactionType> activateTransactionType(@PathVariable Long id) {
        Optional<TransactionType> optionalType = transactionTypeRepository.findById(id);
        
        if (!optionalType.isPresent()) {
            return ResponseEntity.notFound().build();
        }
        
        TransactionType transactionType = optionalType.get();
        transactionType.setActive(true);
        
        TransactionType updatedType = transactionTypeRepository.save(transactionType);
        return ResponseEntity.ok(updatedType);
    }
}
