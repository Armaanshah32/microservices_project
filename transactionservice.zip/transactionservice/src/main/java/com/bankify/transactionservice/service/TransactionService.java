package com.bankify.transactionservice.service;

import com.bankify.transactionservice.entity.Transaction;
import com.bankify.transactionservice.entity.TransactionType;
import com.bankify.transactionservice.repository.TransactionRepository;
import com.bankify.transactionservice.repository.TransactionTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final TransactionTypeRepository transactionTypeRepository;
    private final RestTemplate restTemplate;

    @Autowired
    public TransactionService(TransactionRepository transactionRepository,
                             TransactionTypeRepository transactionTypeRepository,
                             RestTemplate restTemplate) {
        this.transactionRepository = transactionRepository;
        this.transactionTypeRepository = transactionTypeRepository;
        this.restTemplate = restTemplate;

        // Ensure TRANSFER transaction type exists
        ensureTransferTransactionTypeExists();
    }

    private void ensureTransferTransactionTypeExists() {
        Optional<TransactionType> transferType = transactionTypeRepository.findByTypeName("TRANSFER");
        if (!transferType.isPresent()) {
            TransactionType newTransferType = new TransactionType();
            newTransferType.setTypeName("TRANSFER");
            newTransferType.setDescription("Transfer between accounts");
            newTransferType.setActive(true);
            transactionTypeRepository.save(newTransferType);
            System.out.println("Created TRANSFER transaction type");
        }
    }

    public Transaction createTransaction(Transaction transaction) {
        if (transaction.getAccountId() == null || transaction.getAmount() == null || transaction.getTransactionType() == null) {
            throw new IllegalArgumentException("Missing required fields: accountId, amount, or transactionType");
        }

        // Check if this is a transfer transaction
        TransactionType transactionType = transaction.getTransactionType();
        if (transactionType.getTypeName() != null && "TRANSFER".equals(transactionType.getTypeName())) {
            // If it's a transfer, use the dedicated transfer method
            return createTransfer(transaction);
        }

        // Verify if the TransactionType exists in the database
        if (transactionType.getTypeId() != null) {
            boolean exists = transactionTypeRepository.existsById(transactionType.getTypeId());
            if (!exists) {
                throw new IllegalArgumentException("TransactionType with ID " + transactionType.getTypeId() + " does not exist");
            }
            // Fetch the complete TransactionType entity to ensure all fields are populated
            final Long typeId = transactionType.getTypeId(); // Store ID in a final variable
            transactionType = transactionTypeRepository.findById(typeId)
                .orElseThrow(() -> new IllegalArgumentException("TransactionType with ID " + typeId + " not found"));
            transaction.setTransactionType(transactionType);
        } else if (transactionType.getTypeName() != null) {
            // If we have a type name but no ID, try to find it by name
            Optional<TransactionType> existingType = transactionTypeRepository.findByTypeName(transactionType.getTypeName());
            if (existingType.isPresent()) {
                transaction.setTransactionType(existingType.get());
            } else {
                throw new IllegalArgumentException("TransactionType with name '" + transactionType.getTypeName() + "' does not exist");
            }
        } else {
            throw new IllegalArgumentException("TransactionType must have either a valid ID or name");
        }

        // Set default values if not already set
        if (transaction.getCreatedAt() == null) {
            transaction.setCreatedAt(new Date());
        }

        if (transaction.getTimestamp() == null) {
            transaction.setTimestamp(new Date());
        }

        if (transaction.getActive() == null) {
            transaction.setActive(true);
        }

        if (transaction.getStatus() == null) {
            transaction.setStatus("COMPLETED");
        }

        try {
            Transaction savedTransaction = transactionRepository.save(transaction);
            // Convert accountId to account number for balance update
            // This is a temporary solution until the entire system is migrated to use account numbers
            String url = "http://ACCOUNTSERVICE/api/accounts/" + transaction.getAccountId();
            try {
                // Get the account to find its account number
                Object account = restTemplate.getForObject(url, Object.class);
                if (account != null) {
                    // Extract account number and update balance
                    // Note: In a real implementation, you would properly extract the account number
                    // For now, we'll continue using the accountId-based update
                    updateAccountBalanceByAccountNumber(transaction.getSourceAccountNumber(), transaction.getAmount());
                }
            } catch (Exception e) {
                System.out.println("Error getting account: " + e.getMessage());
                // Fall back to using accountId directly
                System.out.println("Warning: Using accountId for balance update. This is deprecated.");
            }
            return savedTransaction;
        } catch (Exception e) {
            System.out.println("Error saving transaction: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to save transaction", e);
        }
    }

    public Optional<Transaction> getTransactionById(Long id) {
        return transactionRepository.findById(id);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }



    private boolean hasSufficientFundsByAccountNumber(String accountNumber, Double amount) {
        String url = "http://ACCOUNTSERVICE/api/accounts/number/" + accountNumber + "/hasSufficientFunds?amount=" + amount;
        try {
            return Boolean.TRUE.equals(restTemplate.getForObject(url, Boolean.class));
        } catch (Exception e) {
            System.out.println("Error checking sufficient funds by account number: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to check account balance by account number", e);
        }
    }

    private void updateAccountBalanceByAccountNumber(String accountNumber, Double amount) {
        String url = "http://ACCOUNTSERVICE/api/accounts/number/" + accountNumber + "/updateBalance?amount=" + amount;
        try {
            restTemplate.put(url, null);
            System.out.println("Account Balance Updated for Account Number: " + accountNumber);
        } catch (Exception e) {
            System.out.println("Error updating account balance by account number: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to update account balance by account number", e);
        }
    }

    public Transaction createTransfer(Transaction transaction) {
        // Validate required fields
        if (transaction.getSourceAccountNumber() == null || transaction.getDestinationAccountNumber() == null ||
            transaction.getAmount() == null || transaction.getAmount() <= 0) {
            throw new IllegalArgumentException("Missing or invalid required fields for transfer");
        }

        // Check if source and destination accounts are different
        if (transaction.getSourceAccountNumber().equals(transaction.getDestinationAccountNumber())) {
            throw new IllegalArgumentException("Source and destination accounts must be different");
        }

        // Check if source account has sufficient funds
        if (!hasSufficientFundsByAccountNumber(transaction.getSourceAccountNumber(), transaction.getAmount())) {
            throw new IllegalArgumentException("Insufficient funds in source account");
        }
        
        // For transfers, explicitly set accountId to null
        transaction.setAccountId(null);
        
        System.out.println("Creating transfer: source=" + transaction.getSourceAccountNumber() + 
                          ", destination=" + transaction.getDestinationAccountNumber() + 
                          ", amount=" + transaction.getAmount() +
                          ", accountId=" + transaction.getAccountId());

        // Set transaction type to TRANSFER
        Optional<TransactionType> transferType = transactionTypeRepository.findByTypeName("TRANSFER");
        if (!transferType.isPresent()) {
            throw new IllegalArgumentException("TRANSFER transaction type not found");
        }
        transaction.setTransactionType(transferType.get());

        // Set default values if not already set
        if (transaction.getCreatedAt() == null) {
            transaction.setCreatedAt(new Date());
        }

        if (transaction.getTimestamp() == null) {
            transaction.setTimestamp(new Date());
        }

        if (transaction.getStatus() == null) {
            transaction.setStatus("PENDING");
        }

        if (transaction.getActive() == null) {
            transaction.setActive(true);
        }

        // Save the transaction first with PENDING status
        Transaction savedTransaction = transactionRepository.save(transaction);

        try {
        // Deduct from source account
            updateAccountBalanceByAccountNumber(transaction.getSourceAccountNumber(), -transaction.getAmount());

            // Add to destination account
            updateAccountBalanceByAccountNumber(transaction.getDestinationAccountNumber(), transaction.getAmount());

            // Update transaction status to COMPLETED
            savedTransaction.setStatus("COMPLETED");
            return transactionRepository.save(savedTransaction);
        } catch (Exception e) {
            // If any error occurs, mark the transaction as FAILED
            savedTransaction.setStatus("FAILED");
            transactionRepository.save(savedTransaction);
            throw new RuntimeException("Failed to process transfer: " + e.getMessage(), e);
        }
    }
}
