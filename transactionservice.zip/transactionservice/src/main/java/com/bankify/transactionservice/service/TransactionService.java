package com.bankify.transactionservice.service;

import com.bankify.transactionservice.entity.Transaction;
import com.bankify.transactionservice.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final RestTemplate restTemplate;

    @Autowired
    public TransactionService(TransactionRepository transactionRepository, RestTemplate restTemplate) {
        this.transactionRepository = transactionRepository;
        this.restTemplate = restTemplate;
    }

    public Transaction createTransaction(Transaction transaction) {
        if (transaction.getAccountId() == null || transaction.getAmount() == null || transaction.getTransactionType() == null) {
            throw new IllegalArgumentException("Missing required fields: accountId, amount, or transactionType");
        }

        transaction.setCreatedAt(new Date());

        try {
            Transaction savedTransaction = transactionRepository.save(transaction);
            updateAccountBalance(transaction.getAccountId(), transaction.getAmount());
            return savedTransaction;
        } catch (Exception e) {
            System.out.println("Error saving transaction: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to save transaction", e);
        }
    }

    public Optional<Transaction> getTransactionById(Long id) {
        return transactionRepository.findById(id);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    private void updateAccountBalance(Long accountId, Double amount) {
        String url = "http://ACCOUNT-SERVICE/api/accounts/" + accountId + "/updateBalance?amount=" + amount;
        try {
            restTemplate.put(url, null);
            System.out.println("Account Balance Updated for Account ID: " + accountId);
        } catch (Exception e) {
            System.out.println("Error updating account balance: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
